import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.jumpdash.game',
  appName: 'Jump Dash',
  webDir: 'www'
};

export default config;
