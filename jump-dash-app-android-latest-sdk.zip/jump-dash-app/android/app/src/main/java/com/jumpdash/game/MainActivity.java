package com.jumpdash.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
