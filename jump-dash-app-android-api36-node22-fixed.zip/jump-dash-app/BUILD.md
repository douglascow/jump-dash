# Jump Dash build requirements

This project uses Capacitor 8 and therefore requires **Node.js 22 or newer**.

- Node.js: 22+
- npm: 10+
- Java: 21
- Android compile SDK: 36
- Android target SDK: 36
- Android minimum SDK: 24
- Gradle wrapper: 8.13
- Android Gradle Plugin: 8.13.0

The GitHub Actions workflow in `.github/workflows/android-build.yml` already selects Node.js 22 and Java 21.

The existing AdMob App ID and ad unit IDs have not been changed.
